const e="/assets/main.tsx-BQJyj0b4.js",t=document.createElement("script");t.type="module";t.src=chrome.runtime.getURL(e);document.body.appendChild(t);
